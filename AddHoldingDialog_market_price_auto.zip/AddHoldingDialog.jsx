import {
  useEffect,
  useState,
} from "react";
 
import {
  Alert,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  TextField,
  Typography,
} from "@mui/material";
 
import {
  DataGrid,
} from "@mui/x-data-grid";
 
import {
  addHolding,
  getReferenceSecurities,
  getsecurityPrice,
} from "../api/api";
 
 
function AddHoldingDialog({
  open,
  onClose,
  portfolio,
  onAdded,
}) {
 
  const [rows, setRows] =
    useState([]);
 
  const [total, setTotal] =
    useState(0);
 
  const [loading, setLoading] =
    useState(false);
 
  const [search, setSearch] =
    useState("");
 
  const [appliedSearch, setAppliedSearch] =
    useState("");
 
  const [quantityMap, setQuantityMap] =
    useState({});

  const[priceMap, setPriceMap] = useState({});
  const[priceLoadingMap, setPriceLoadingMap] = useState({});

 
  const [message, setMessage] =
    useState("");
 
  const [error, setError] =
    useState("");
 
 
  const [
    paginationModel,
    setPaginationModel,
  ] = useState({
 
    page: 0,
    pageSize: 25,
 
  });
 
 
  async function loadPrices(securities) {
    if (!securities || securities.length === 0) {
      return;
    }

    const securityIds = securities
      .map((security) => security.security_id)
      .filter((id) => id !== undefined && id !== null);

    if (securityIds.length === 0) {
      return;
    }

    setPriceLoadingMap((previous) => {
      const next = { ...previous };
      securityIds.forEach((securityId) => {
        next[securityId] = true;
      });
      return next;
    });

    try {
      const results = await Promise.all(
        securityIds.map(async (securityId) => {
          try {
            const priceData = await getsecurityPrice(
              securityId,
              "2026-10-01"
            );

            const price = Number(priceData?.close_price);

            return {
              securityId,
              price: Number.isFinite(price) ? price : undefined,
            };
          } catch (err) {
            console.error(
              "Unable to load market price:",
              securityId,
              err
            );
            return { securityId, price: undefined };
          }
        })
      );

      setPriceMap((previous) => {
        const next = { ...previous };

        results.forEach(({ securityId, price }) => {
          if (price !== undefined) {
            next[securityId] = price;
          }
        });

        return next;
      });
    } finally {
      setPriceLoadingMap((previous) => {
        const next = { ...previous };

        securityIds.forEach((securityId) => {
          next[securityId] = false;
        });

        return next;
      });
    }
  }

  async function loadSecurities() {
 
    if (!portfolio) {
      return;
    }
 
 
    try {
 
      setLoading(true);
      setError("");
 
 
      const isAll =
        paginationModel.pageSize === -1;
 
 
      const data =
        await getReferenceSecurities({
 
          exchange:
            portfolio.exchange,
 
          search:
            appliedSearch,
 
          page:
            isAll
              ? 1
              : paginationModel.page + 1,
 
          pageSize:
            isAll
              ? 2100
              : paginationModel.pageSize,
 
        });
 
 
      const securities = data.rows || [];

      setRows(securities);

      setTotal(
        data.total || 0
      );

      // Automatically fetch market prices for all securities
      // currently displayed on this grid page.
      await loadPrices(securities);
 
    }
    catch (err) {
 
      console.error(err);
 
      setError(
        "Unable to load securities"
      );
 
    }
    finally {
 
      setLoading(false);
 
    }
  }
 
 
  useEffect(() => {
 
    if (
      open &&
      portfolio
    ) {
 
      loadSecurities();
 
    }
 
  }, [
    open,
    portfolio?.portfolio_id,
    paginationModel.page,
    paginationModel.pageSize,
    appliedSearch,
  ]);
 
 
  useEffect(() => {
 
    if (open) {
 
      setSearch("");
      setAppliedSearch("");
      setQuantityMap({});
      setMessage("");
      setError("");
 
      setPaginationModel({
        page: 0,
        pageSize: 25,
      });
 
    }
 
  }, [open]);
 
 
  async function handleQuantityChange(
    securityId,
    value
  ) {
 
    setQuantityMap(
      (previous) => ({
 
        ...previous,
 
        [securityId]:
          value,
 
      })
    );


    const quantity = Number(value);
    if(!quantity || quantity <= 0){
      return;
    }

    if (priceMap[securityId] === undefined) {
      try {
        setPriceLoadingMap((previous) => ({
          ...previous,
          [securityId]: true,
        }));

        const priceData = await getsecurityPrice(
          securityId,
          "2026-10-01"
        );

        const price = Number(priceData?.close_price);

        if (Number.isFinite(price)) {
          setPriceMap((previous) => ({
            ...previous,
            [securityId]: price,
          }));
        }
      } catch (err) {
        console.error(
          "Unable to load security price:",
          err
        );
        setError("Unable to load security price");
      } finally {
        setPriceLoadingMap((previous) => ({
          ...previous,
          [securityId]: false,
        }));
      }
    }));
    }
  }
 
 
  async function handleBuy(
    security
  ) {
 
    const quantity =
      Number(
        quantityMap[
          security.security_id
        ]
      );
 
 
    if (
      !quantity ||
      quantity <= 0
    ) {
 
      setError(
        "Enter a valid quantity"
      );
 
      return;
 
    }
 
 
    try {
 
      setError("");
      setMessage("");
 
 
      await addHolding(
 
        portfolio.portfolio_id,
 
        {
 
          security_id:
            security.security_id,
 
          quantity:
            quantity,
 
        }
 
      );
 
 
      setMessage(
        `${security.symbol} purchased successfully`
      );
 
 
      setQuantityMap(
        (previous) => ({
 
          ...previous,
 
          [security.security_id]:
            "",
 
        })
      );
 
 
      if (onAdded) {
 
        await onAdded();
 
      }
 
    }
    catch (err) {
 
      console.error(err);
 
      setError(
 
        err.response?.data?.detail
        ||
        "Unable to buy security"
 
      );
 
    }
 
  }
 
 
  const columns = [
 
    {
      field: "symbol",
      headerName: "Symbol",
      width: 140,
    },
 
    {
      field: "security_name",
      headerName: "Security Name",
      width: 250,
    },
 
    {
      field: "stock_exchange",
      headerName: "Exchange",
      width: 120,
    },
 
    {
      field: "asset_class",
      headerName: "Asset Class",
      width: 160,
    },
 
    {
      field: "sector",
      headerName: "Sector",
      width: 170,
    },
 
    {
      field: "currency",
      headerName: "Currency",
      width: 100,
    },
 
    {
      field: "quantity",
      headerName: "Quantity",
      width: 130,
      sortable: false,
 
      renderCell: (params) => (
 
        <TextField
 
          size="small"
 
          type="number"
 
          value={
            quantityMap[
              params.row.security_id
            ]
            || ""
          }
 
          onChange={(event) =>{
              const securityId = params.row.security_id ?? params.row.id;
              handleQuantityChange(
                securityId,
                event.target.value
              );
          }
        }
 
          slotProps={{
            htmlInput: {
              min: 0.0001,
            },
          }}
 
        />
 
      ),
 
    },

    {
      field: "price_per_unit",
      headerName: "Price Per Unit",
      width: 150,
      sortable: false,
      filterable: false,
      renderCell: (params) => {
        const securityId = params.row.security_id??params.row.id;
        const price = priceMap[securityId];
        const loading = priceLoadingMap[securityId];
        if(loading){
          return "Loading....";
        }
        if(price === undefined){
          return "-";
        }
        return `${Number(price).toFixed(2)}`;

      },
    },

    {
      field: "total_price",
      headerName: "Total Price",
      width: 150,
      sortable: false,
      filterable: false,
      renderCell: (params) => {
        const securityId = params.row.security_id ?? params.row.id;
        const quantity = Number(quantityMap[securityId]) || 0;
        const price = priceMap[securityId];
        if(quantity <= 0 || price === undefined){
          return "-";
        }
        const total= quantity * Number(price);
        return `${total.toFixed(2)}`;
      },
    },
 
    {
      field: "buy",
      headerName: "Action",
      width: 110,
 
      sortable: false,
      filterable: false,
 
      renderCell: (params) => (
 
        <Button
          size="small"
          variant="contained"
 
          onClick={() =>
            handleBuy(
              params.row
            )
          }
        >
          Buy
        </Button>
 
      ),
 
    },
 
  ];
 
 
  return (
 
    <Dialog
      open={open}
      onClose={onClose}
 
      fullWidth
      maxWidth="lg"
    >
 
      <DialogTitle>
 
        Add Holding
 
      </DialogTitle>
 
 
      <DialogContent>
 
        {portfolio && (
 
          <Typography
            sx={{
              mb: 2,
            }}
          >
 
            Portfolio:{" "}
 
            <strong>
              {portfolio.portfolio_name}
            </strong>
 
            {" | "}
 
            Preferred Exchange:{" "}
 
            <strong>
              {portfolio.exchange}
            </strong>
 
          </Typography>
 
        )}
 
 
        {error && (
 
          <Alert
            severity="error"
            sx={{
              mb: 2,
            }}
          >
            {error}
          </Alert>
 
        )}
 
 
        {message && (
 
          <Alert
            severity="success"
            sx={{
              mb: 2,
            }}
          >
            {message}
          </Alert>
 
        )}
 
 
        <Box
          sx={{
            display: "flex",
            gap: 1,
            mb: 2,
          }}
        >
 
          <TextField
 
            fullWidth
 
            size="small"
 
            label="Search securities"
 
            value={
              search
            }
 
            onChange={(event) =>
              setSearch(
                event.target.value
              )
            }
 
            onKeyDown={(event) => {
 
              if (
                event.key === "Enter"
              ) {
 
                setPaginationModel(
                  (previous) => ({
                    ...previous,
                    page: 0,
                  })
                );
 
                setAppliedSearch(
                  search
                );
 
              }
 
            }}
 
          />
 
 
          <Button
            variant="outlined"
 
            onClick={() => {
 
              setPaginationModel(
                (previous) => ({
                  ...previous,
                  page: 0,
                })
              );
 
              setAppliedSearch(
                search
              );
 
            }}
          >
            Search
          </Button>
 
        </Box>
 
 
        <Box
          sx={{
            height: 450,
            width: "100%",
          }}
        >
 
          <DataGrid
 
            rows={
              rows
            }
 
            columns={
              columns
            }
 
            getRowId={
              (row) =>
                row.security_id
            }
 
            loading={
              loading
            }
 
            rowCount={
              paginationModel.pageSize === -1
                ? rows.length
                : total
            }
 
            paginationMode={
              paginationModel.pageSize === -1
                ? "client"
                : "server"
            }
 
            paginationModel={
              paginationModel
            }
 
            onPaginationModelChange={
              (newModel) => {
 
                setPaginationModel({
 
                  page:
                    newModel.pageSize !==
                    paginationModel.pageSize
                      ? 0
                      : newModel.page,
 
                  pageSize:
                    newModel.pageSize,
 
                });
 
              }
            }
 
            pageSizeOptions={[
 
              5,
              10,
              25,
              50,
              100,
 
              {
                value: -1,
                label: "All",
              },
 
            ]}
 
            disableRowSelectionOnClick
 
          />
 
        </Box>
 
      </DialogContent>
 
 
      <DialogActions>
 
        <Button
          onClick={
            onClose
          }
        >
          Close
        </Button>
 
      </DialogActions>
 
    </Dialog>
 
  );
 
}
 
 
export default AddHoldingDialog;
 